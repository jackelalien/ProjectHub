ReadMe: Fugro Assignment

---------------------------------------------------------------------------

Created by: Jack Laborde
Objective: Calculate the offset and station from a point to a polyline.

---------------------------------------------------------------------------

Contents:

I) Requirements
II) Project Summary
III) Usage Instructions
IV) Explanation of Methods
V) Side Notes / Bugs
VI) File List

---------------------------------------------------------------------------
 
I) REQUIREMENTS

This project only has one known requirement (besides a Windows 10 PC), and that is
.NET Framework 4.6.1, which the application was developed on. Windows 10 may not be
necessary, but recommended.

---------------------------------------------------------------------------

II) PROJECT SUMMARY

Overall, this project is meant to demonstrate the calculation of offset and station
from a user-defined point to a given polyline, defined in an ASCII text file. This project
presents a WPF window allowing the user to upload a defined file (one is given, see Section 
VI). The user then types in or clicks on the given window of the polyline to define a 
custom point. With that, the offset and station can be calculated and the result shown to 
the user.

---------------------------------------------------------------------------

III) USAGE INSTRUCTIONS

To use this project properly, you will be presented with a window showing a blank canvas, some
text boxes, and some buttons. The first step is to load the polyline file using the Load/Create
Polyline button. Once you select a proper, comma separated file, the system will automatically
render a polyline to the canvas for you to view. You can then enter a manual Northing/Easting 
value or click on the canvas to set a point yourself. 

Afterwards, click the Calculate button and the program will produce the required Offset and 
Station outputs.

If loading a large file, the UI is not blocked during this time, so if you need to cancel, hit
the Cancel button at the bottom of the window.

---------------------------------------------------------------------------

IV) EXPLANATION OF METHODS

For this project, I tried to compartmentalize my code as much as possible into separate 
componentsto keep things clean and readable. The main execution occurs in MainWindow.xaml.cs, 
which holds the mainclass, a background worker, and references to the other components. The 
components are made into static classes, which allow for cleaner code and no need to create
unnecessary references and allocation. 

I also tried to keep class variables low, only having a background worker to demonstrate 
multi-threading (so that the UI is unblocked during calculation), and a reference to the current
Polyline and user point.

The UI and Background worker run in this main class, but calculations are run in separate classes
to keep the code clean and readable.

---------------------------------------------------------------------------

V) SIDE NOTES / BUGS

For this project, while it may be unneccessary, I intentionally added background workers to not
block the UI while processing, which for larger polylines would work just fine. This is due to
my previous experience with Advanced CAD Services, where I had to render large shape files that 
took a long time to process.

I also toyed with adding in Zooming/Panning to the canvas window, but my system was giving me some
trouble with it, so I left that out. Unfortunately, that means negative lines may not be rendered,
but will exist.

Another edge case is if the system detects a bad line when parsing (such as an extra comma, or a
non-parseable number), the system will still render what is returned. This is not a bug - as parts
of the line came through okay. If no line comes through, it will still act normally.

---------------------------------------------------------------------------

VI) FILE LIST

- /FugroAssignment_JackLaborde - Contains the source code
-- /bin
--- /Release - Contains the binary executable
- /Input - Contains the necessary input files
- README
- Solution File
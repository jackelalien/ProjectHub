﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Assignment_JackLaborde;


namespace Assignment_Tests
{
    interface IFileSystem
    {
        bool FileExists(string filename);
        DateTime GetCreateionDate(string filename);
    }

    [TestClass]
    public class PolylineManagerTest_Entirety
    {
        [TestMethod]
        public void Parse_Valid_Separate_Lines()
        {
            //Arrange

            //Act

            //Asset
        }

        [TestMethod]
        public void Parse_Valid_Same_Line()
        {

        }

        [TestMethod]
        public void Parse_Valid_Mixed_Lines()
        {

        }

        [TestMethod]
        public void Parse_Invalid_Separate_Lines()
        {

        }

        [TestMethod]
        public void Parse_Invalid_Same_Line()
        {

        }

        [TestMethod]
        public void Parse_Invalid_Mixed_Lines()
        {

        }

    }

    [TestClass]
    public class PolylineManagerTest_ErrorCodes
    {
        [TestMethod]
        public void Throw_No_Commas()
        {

        }

        [TestMethod]
        public void Throw_Invalid_Len()
        {

        }

        [TestMethod]
        public void Throw_Invalid_Num()
        {

        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using Microsoft.Win32;
using Assignment_JackLaborde.Components;
using System.ComponentModel;

namespace Assignment_JackLaborde
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // Class Variables
        BackgroundWorker worker;
        List<float[]> currentLine;
        Point userPoint;
        bool pointIsGood;



        /// <summary>
        /// Initial Constructor - Initialize Component and variables.
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();
            currentLine = new List<float[]>();
            userPoint = new Point();
            pointIsGood = false;

            //Create a background worker to handle most of the load in a separate thread (so as to not block the UI)
            worker = new BackgroundWorker();
            worker.WorkerReportsProgress = true;
            worker.WorkerSupportsCancellation = true;
            worker.ProgressChanged += new ProgressChangedEventHandler(workerProgress);
        }



        // Event Handler - Calculate Button is Clicked
        private void Btn_Calculate_Click(object sender, RoutedEventArgs e)
        {
            // Only run if the point is good (the button will be disabled, but it's good to double check in case of edge cases).
            if(pointIsGood)
            {
                // Update the background worker.
                worker.DoWork += new DoWorkEventHandler(CalculateBackground);
                worker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(workerCompleted_Calculations);

                // Run the calculations in the background.
                if (worker.IsBusy != true)
                {
                    lbl_Status.Content = "Working...";
                    worker.RunWorkerAsync();
                }
                else
                {
                    MessageBox.Show("Cannot run - operation in progress.");
                }

            }

        }



        // Event Handler - Load Polyline Button is Clicked
        private void Btn_LoadPolyLine_Click(object sender, RoutedEventArgs e)
        {
            // Run the background worker to Load a Polyline File
            worker.DoWork += new DoWorkEventHandler(LoadPolyLine_Background);
            worker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(workerCompleted_FileLoading);

            if (worker.IsBusy != true)
            {
                lbl_Status.Content = "Working...";
                worker.RunWorkerAsync();
            }  
            else
            {
                MessageBox.Show("Cannot run - operation in progress.");
            }
        }


        // Event Handler - Cancel Background Worker
        private void btn_CancelWorker_Click(object sender, RoutedEventArgs e)
        {
            // Cancel the background worker if cancellation is available.
            if(worker.WorkerSupportsCancellation)
            {
                worker.CancelAsync();
                lbl_Status.Content = "Idle";
            }
        }



        // Allow the user to open a polyline file
        private string LoadPolyFile()
        {
            // Initial String
            string file = "No File Selected";

            // Dialog Options to open a needed polyline file.
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "All Files (*.*)|*.*|Text files (*.txt)|*.txt|Ascii Files (*.ascii)|*.ascii";
            openFileDialog.Title = "Browse for Polyline Text/ASCII Files";
            openFileDialog.CheckFileExists = true;
            openFileDialog.CheckPathExists = true;
            
            // When the user clicks OK and loads a polyline file.
            if(openFileDialog.ShowDialog() == true)
            {
                file = openFileDialog.FileName;
                txtBox_PolylineFile.Dispatcher.Invoke((Action)delegate {
                    txtBox_PolylineFile.Text = file;
                });
            }

            return file;
        }



        /// <summary>
        /// BACKGROUND WORKER FUNCTIONS - The following section presents the functionality of the background workers.
        /// </summary>

        // Event Handler - Load Polyline in the background.
        private void LoadPolyLine_Background(object sender, DoWorkEventArgs e)
        {
            BackgroundWorker w = sender as BackgroundWorker;

            // Load the file path into memory and parse the file.
            string file = LoadPolyFile();

            // Cancel if needed.
            if(w.CancellationPending || file == "No File Selected")
            {
                w.ReportProgress(100);
                e.Cancel = true;
                return;
            }

            // Parse the result to a polyline.
            e.Result = PolylineManager.ParseToPolyline(file, ref w);

        }



        // Event Handler - Calculate the Station and Offset in the background.
        private void CalculateBackground(object sender, DoWorkEventArgs e)
        {
            BackgroundWorker w = sender as BackgroundWorker;

            // Load the file path into memory and parse the file.
            KeyValuePair<Point, double> pointAndOffset = StationOffsetCalculator.OffsetCalculation(currentLine, userPoint);
            w.ReportProgress(50);

            if (w.CancellationPending)
            {
                w.ReportProgress(100);
                e.Cancel = true;
                return;
            }

            double station = StationOffsetCalculator.StationCalculation(currentLine, pointAndOffset.Key);
            w.ReportProgress(100);

            e.Result = new KeyValuePair<Point, KeyValuePair<double, double>>(pointAndOffset.Key, new KeyValuePair<double, double>(pointAndOffset.Value, station));

        }



        // Event Handler - Executes when the worker completes in the file loading section.
        private void workerCompleted_FileLoading(object sender, RunWorkerCompletedEventArgs e) //_FileLoading
        {
            if(e.Cancelled)
            {
                lbl_Status.Content = "Idle";
                progressBar.Value = 0;
            }
            else
            {
                // Render the polyline if not cancelled.
                currentLine = (List<float[]>)e.Result;
                RenderPolyline(currentLine);
                lbl_Status.Content = "Idle";
                progressBar.Value = 0;
            }

            // Remove worker functions.
            worker.DoWork -= LoadPolyLine_Background;
            worker.RunWorkerCompleted -= workerCompleted_FileLoading;
        }



        // Event Handler - Executes when the worker completes the calculations in the background.
        private void workerCompleted_Calculations(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                lbl_Status.Content = "Idle";
                progressBar.Value = 0;
            }
            else
            {
                // Set the text boxes when done.
                KeyValuePair<Point, KeyValuePair<double, double>> results = (KeyValuePair<Point, KeyValuePair<double, double>>)e.Result;

                txtBox_Offset.Text = results.Value.Key.ToString();
                txtBox_Station.Text = results.Value.Value.ToString();
                lbl_Status.Content = "Idle";
                progressBar.Value = 0;
            }

            // Remove worker functions.
            worker.DoWork -= CalculateBackground;
            worker.RunWorkerCompleted -= workerCompleted_Calculations;
        }



        // Event Handler - Worker reports progress to update the progress bar and labels.
        private void workerProgress(object sender, ProgressChangedEventArgs e)
        {
            progressBar.Value = e.ProgressPercentage;

            if(e.ProgressPercentage == 100)
            {
                lbl_Status.Content = "Idle";
            }
        }


        // END BACKGROUND WORKER FUNCTIONS


        // Event Handler - Canvas is clicked - draw a point and update the canvas and Easting/Northing Values.
        private void polyCanvas_MouseUp(object sender, MouseButtonEventArgs e)
        {
            Point p = Mouse.GetPosition(polyCanvas);
            updateCanvas(p, true);
            Btn_Calculate.IsEnabled = true;
        }



        // Event Handler - Text Changed on the Easting Textbox. Just update the Textbox to check if the point is parsed as a double.
        private void txtBox_Easting_TextChanged(object sender, TextChangedEventArgs e)
        {
            updateTextBox(ref txtBox_Easting, true);
        }



        // Event Handler - Text Changed on the Northing Textbox. Just update the Textbox to check if the point is parsed as a double.
        private void txtBox_Northing_TextChanged(object sender, TextChangedEventArgs e)
        {
            updateTextBox(ref txtBox_Northing, false);
        }



        /// <summary>
        /// RenderPolyline - Draws the loaded polyline onto the canvas for visualization.
        /// </summary>
        /// <param name="line">The current line to render.</param>
        public void RenderPolyline(List<float[]> line)
        {
            polyCanvas.Children.Clear();

            // Set up brushes.
            SolidColorBrush black = new SolidColorBrush();
            SolidColorBrush brown = new SolidColorBrush();
            black.Color = Colors.Black;
            brown.Color = Colors.Brown;

            // Start and end points to render on the canvas.
            Rectangle start = new Rectangle();
            Rectangle end = new Rectangle();

            // Brush Settings for start and end points
            start.Stroke = black;
            start.StrokeThickness = 6;
            start.Width = 6;
            start.Fill = black;

            end.Stroke = black;
            end.StrokeThickness = 6;
            end.Width = 6;
            end.Fill = black;

            // Render the polyline and its points.
            Polyline ln = new Polyline();
            PointCollection polyPoints = new PointCollection();
            Point startPoint = new Point();
            Point endPoint = new Point();

            ln.Stroke = brown;
            ln.StrokeThickness = 4;

            int index = 0;

            // Add each point from the line to the renderable polyline.
            foreach (float[] points in line)
            {

                Point point = new Point(points[0], points[1]);
                if (index == 0)
                {
                    startPoint = point;
                }
                if (index == line.Count - 1)
                {
                    endPoint = point;
                }

                polyPoints.Add(point);
                index++;
            }

            ln.Points = polyPoints;
            
            // Set Start and End Point Positions
            Canvas.SetLeft(start, startPoint.X - start.Width / 2);
            Canvas.SetTop(start, startPoint.Y - start.Width / 2);

            Canvas.SetLeft(end, endPoint.X - end.Width / 2);
            Canvas.SetTop(end, endPoint.Y - end.Width / 2);
            

            // Add the points to the canvas.
            polyCanvas.Children.Add(ln);
            polyCanvas.Children.Add(start);
            polyCanvas.Children.Add(end);

        }



        /// <summary>
        /// updateCanvas - Draws the current point on the canvas and removes old points.
        /// </summary>
        /// <param name="p">The current point to draw</param>
        /// <param name="updateTextBox">Update the textboxes to the clicked position.</param>
        private void updateCanvas(Point p, bool updateTextBox)
        {
            userPoint = p;

            if(updateTextBox)
            {
                txtBox_Easting.Text = p.X.ToString();
                txtBox_Northing.Text = p.Y.ToString();
            }
            
            // Set up ellipse point to show where the user clicked.
            int dotSize = 10;
            Ellipse currentDot = new Ellipse();
            currentDot.Stroke = new SolidColorBrush(Colors.Green);
            currentDot.StrokeThickness = 3;
            currentDot.Height = dotSize;
            currentDot.Width = dotSize;
            currentDot.Fill = new SolidColorBrush(Colors.Green);
            currentDot.Margin = new Thickness(p.X - currentDot.Width/2, p.Y - currentDot.Height/2, 0, 0); // Sets the position.

            //Remove old points
            List<UIElement> removeElements = new List<UIElement>();
            for (int i = 0; i < polyCanvas.Children.Count; i++)
            {
                if (polyCanvas.Children[i].GetType() == typeof(Ellipse))
                {
                    removeElements.Add(polyCanvas.Children[i]);
                }
            }

            foreach (UIElement elem in removeElements)
            {
                polyCanvas.Children.Remove(elem);
            }

            removeElements.Clear();

            // Add the dot to the canvas.
            polyCanvas.Children.Add(currentDot);
        }



        /// <summary>
        /// updateTextBox - Updates the text box to check if the user value is a number.
        /// </summary>
        /// <param name="txtBox">The textbox reference to check.</param>
        /// <param name="isX">Checks whether to update the X value or not.</param>
        private void updateTextBox(ref TextBox txtBox, bool isX)
        {
            double r = 0.0;

            // Try and parse it as a double. If its not, disable the calculate button.
            if (Double.TryParse(txtBox.Text, out r))
            {
                // Update the user point.
                if (isX)
                    userPoint.X = r;
                else
                    userPoint.Y = r;

                // Update the canvas and calculate button.
                pointIsGood = true;
                updateCanvas(userPoint, false);
                Btn_Calculate.IsEnabled = true;
            }
            else
            {
                pointIsGood = false;
                Btn_Calculate.IsEnabled = false;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace Assignment_JackLaborde.Components
{
    public static class StationOffsetCalculator
    {
        const float EPSILON = 0.001f;

        /// <summary>
        /// OffSetCalculation - Calculates the offset of the point to a polyline by finding the perpendicular distance.
        /// </summary>
        /// <param name="polyLine">The whole polyline being passed in.</param>
        /// <param name="point">The point defined by the user.</param>
        /// <returns>Returns the final, smallest distance from point to polyline and the intersecting point.</returns>
        public static KeyValuePair<Point, double> OffsetCalculation(List<float[]> polyLine, Point point)
        {
            double distance = -1.0;

            // Create a Key Value Pair so that we can return both the Point and the Distance
            KeyValuePair<Point, double> pointAndDistance = new KeyValuePair<Point, double>();

            // Given a polyline, we need to calculate the shortest perpendicular distance.
            // To do so, we must first loop through each line segment and perform the calculation.
            for(int i = 0; i < polyLine.Count; i++)
            {    
                // For each i, create a line segment, and get the start and end points.
                List<float[]> currentSegment = new List<float[]>();
                float[] startPt = polyLine[i];
                float[] endPt = polyLine[i + 1];
                currentSegment.Add(startPt);
                currentSegment.Add(endPt);

                // Get the Distance for the current line segment and intersecting point
                double currentDist = DistanceFromPointToLineSegment(point, currentSegment);
                Point intersectPt = GetIntersectingPointOnLine(point, currentSegment, currentDist);

                if (distance == -1.0 || currentDist < distance)
                {
                        
                    pointAndDistance = new KeyValuePair<Point, double>(intersectPt, currentDist);
                    distance = currentDist;
                }

                if ((i + 1) == polyLine.Count - 1)
                {
                    break;
                }
 
            }

            return pointAndDistance;

        }


        /// <summary>
        /// StationCalculation - Calculates Station (Distance) along a polyline, down to the intersecting point of the offset.
        /// </summary>
        /// <param name="polyLine">The current polyline</param>
        /// <param name="linePoint">The point on the line where intersection occurs.</param>
        /// <returns>Returns the station value, or distance along the line.</returns>
        public static double StationCalculation(List<float[]> polyLine, Point linePoint)
        {
            double distance = 0.0;

            // Convert the point to a float array. 
            float[] linePt = { (float)linePoint.X, (float)linePoint.Y };

            for(int i = 0; i < polyLine.Count; i++)
            {
                List<float[]> currentSegment = new List<float[]>();
                float[] startPt = polyLine[i];
                float[] endPt = polyLine[i + 1];
                currentSegment.Add(startPt);
                currentSegment.Add(endPt);

                // After setting up the line segment, check if the point lies on the line segment.
                bool check = CheckPointOnLineSegment(linePoint, currentSegment);

                // If the point lies on the segment, add the distance and stop the calcuations.
                if(check)
                {
                    // Clear and remake the current segment with adding the start and the line point. Then add distance
                    currentSegment.Clear();
                    currentSegment.Add(startPt);
                    currentSegment.Add(linePt);
                    distance += AddDistance(currentSegment);
                    break;

                }
                else
                {
                    // Just add distance if the point is not on the line segment.
                    distance += AddDistance(currentSegment);
                }


                if ((i + 1) == polyLine.Count - 1)
                {
                    break;
                }
            }

            return distance;
        }



        /// <summary>
        /// Add Distance - Computes the length of a line segment and returns the length.
        /// </summary>
        /// <param name="lineSegment">The current Line Segment</param>
        /// <returns>The length of the line to add to the distance.</returns>
        private static double AddDistance(List<float[]> lineSegment)
        {
            // Define start and end points on the given line segment
            Point start = new Point(lineSegment[0][0], lineSegment[0][1]);
            Point end = new Point(lineSegment[1][0], lineSegment[1][1]);

            return Math.Sqrt(Math.Pow((end.Y - start.Y), 2) + Math.Pow((end.X - start.X), 2));
        }



        /// <summary>
        /// CheckPointOnLineSegment - Checks if a point is on a line segment, and returns true if so.
        /// </summary>
        /// <param name="point">The point to check against</param>
        /// <param name="lineSegment">the line segment to see if the point exists on</param>
        /// <returns>True if the point is on the line segment, false otherwise.</returns>
        private static bool CheckPointOnLineSegment(Point point, List<float[]> lineSegment)
        {
            Point start = new Point(lineSegment[0][0], lineSegment[0][1]);
            Point end = new Point(lineSegment[1][0], lineSegment[1][1]);

            // Line Calculations (Slope, Y-intercept) 
            double a = (end.Y - start.Y) / (end.X - start.X);
            double b = start.Y - a * start.X;

            // Check if close to zero. It is less than an epsilon because of float's precision.
            // The line equation helps us to find out if the point is on the line segment.
            if(Math.Abs(point.Y - (a*point.X+b)) < EPSILON)
            {
                return true;
            }

            return false;

        }



        /// <summary>
        /// DistanceFromPointToLineSegment - Calculates the distance from the point to the line segment using projection and distance equations.
        /// </summary>
        /// <param name="point">The user defined point</param>
        /// <param name="lineSegment">The current line segment to calculate on</param>
        /// <returns>Returns the perpendicular distance from the point to the line</returns>
        private static double DistanceFromPointToLineSegment(Point point, List<float[]> lineSegment)
        {
            // The point is defined as (x0, y0), with a distance d (returned) away perpendiculary from the line
            // So first, a line (Points Start and End) is given, and a vector perpendicular to the line is: [y2-y1 | -(x2-x1)] (Separator is vertical separation, 2x2 matrix)
            // In the following equation, we project Vector [x1 - startX | x2 - startY ] onto the vector in the previous comment.

            Point start = new Point(lineSegment[0][0], lineSegment[0][1]);
            Point end = new Point(lineSegment[1][0], lineSegment[1][1]);

            // Define a new closest point (helps in calculations)
            Point closest = new Point();

            // Get the slope of the line.
            double dx = end.X - start.X;
            double dy = end.Y - start.Y;

            // This sees if this is a point and not a line segment.
            if ((dx == 0) && (dy == 0))
            {
                // return the distance of the point to the point.
                closest = start;
                dx = point.X - start.X;
                dy = point.Y - start.Y;
                return Math.Sqrt(dx * dx + dy * dy);
            }

            // Minimize the distance with a t value, which is between 0 and 1. 
            double t = ((point.X - start.X) * dx + (point.Y - start.Y) * dy) /
                (dx * dx + dy * dy);

            // If t < 0, it is closest to the starting point and not the line segment itself. 
            // This and t > 1 handles cases where the point is so far off that the closest point is a point and not a perpendicular distance.
            if (t < 0)
            {
                closest = new Point(start.X, start.Y);
                dx = point.X - start.X;
                dy = point.Y - start.Y;
            }
            // If t > 1, it is closest to the end point.
            else if (t > 1)
            {
                closest = new Point(end.X, end.Y);
                dx = point.X - end.X;
                dy = point.Y - end.Y;
            }
            // A middle point somewhere on the line segment.
            else
            {
                closest = new Point(start.X + t * dx, start.Y + t * dy);
                dx = point.X - closest.X;
                dy = point.Y - closest.Y;
            }

            return Math.Sqrt(dx * dx + dy * dy);

        }


        /// <summary>
        /// GetIntersectingPointOnLine - Gets the intersecting Point on the line for future station calculation (this is retrieved during the offset calculation).
        /// </summary>
        /// <param name="point">The user defined point</param>
        /// <param name="lineSegment">The current line segment</param>
        /// <param name="distance">The distance from the point to the line.</param>
        /// <returns>Returns the Intersecting Point</returns>
        private static Point GetIntersectingPointOnLine(Point point, List<float[]> lineSegment, double distance)
        {
            // We must create a line from the point to the intersection, and return that as a float[]. 
            // A perpendicular line is the reciprocal of the original line.

            Point start = new Point(lineSegment[0][0], lineSegment[0][1]);
            Point end = new Point(lineSegment[1][0], lineSegment[1][1]);

            // Create the line needed to intersect.
            double kNum = ((end.Y - start.Y) * (point.X - start.X) - (end.X - start.X) * (point.Y - start.Y));
            double kDen = (Math.Pow(end.Y - start.Y, 2) + Math.Pow(end.X - start.X, 2));
            double k = kNum / kDen;

            // Get the intersection point and return that point.
            double intersectX = point.X - k * (end.Y - start.Y);
            double intersectY = point.Y + k * (end.X - start.X);

            Point pt = new Point(intersectX, intersectY);

            return pt;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.IO;
using System.ComponentModel;

namespace Assignment_JackLaborde.Components
{
    public enum ErrorCode
    {
        NO_COMMAS_DETECTED,
        INVALID_LENGTH,
        INVALID_NUMBER,
        NONE
    }


    public static class PolylineManager
    {

        /// <summary>
        /// ParseToPolyline - Parses a file into a series of float X/Y coordinates for use in creating the polyline.
        /// </summary>
        /// <param name="file">The file of X/Y Coordinates to parse</param>
        /// <param name="w">The background worker, solely for reporting progress.</param>
        /// <returns></returns>
        public static List<float[]> ParseToPolyline(string file, ref BackgroundWorker w)
        {
            List<float[]> finalArray = new List<float[]>();

            try
            {
                // Read all the lines of the file.
                string[] lines = File.ReadAllLines(file);
                int len = lines.Length;
                int index = 0;

                foreach (string line in lines)
                {
                    // 1 - Check Line Validity. Throw Error and break if not valid.
                    ErrorCode err = CheckLineValidity(line, ref w);
                    if(err != ErrorCode.NONE)
                    {
                        bool cont = ThrowErrorMessage(err);
                        if (!cont)
                            break;
                    }

                    // 2 - Parse Array
                    string[] split = line.Split(',');
                    w.ReportProgress((index / len) * 100);

                    // Some programs may generate everything on one line or multiple XY Coordinates per line - this is why we handle an edge case using the for loop.
                    if (split.Length % 2 == 0)
                    {
                        for(int i = 0; i < split.Length; i += 2)
                        {
                            float x = float.Parse(split[i]);
                            float y = float.Parse(split[i+1]);
                            float[] z = { x, y };
                            finalArray.Add(z);
                        }
                    }

                    index++;
                    

                }
            }
            catch(Exception e)
            {
                Console.Write(e.Message);
            }
            
            return finalArray;
        }


        
        /// <summary>
        /// CheckValidity - Checks if a line is valid according the program parameters.
        /// </summary>
        /// <param name="line">The current line of the string array to parse</param>
        /// <param name="w">The Background Worker to report progress</param>
        /// <returns>Error Code to determine what possible error may have occurred, if any.</returns>
        private static ErrorCode CheckLineValidity(string line, ref BackgroundWorker w)
        {
            // If the line does not contain any commas as dictated by the parameters, return immediately, as this may not be a valid file.
            if(!line.Contains(','))
            {
                return ErrorCode.NO_COMMAS_DETECTED;
                
            }

            // Line does contain commas, now we need to split it by the commas, and make sure the numbers are even.
            string[] split = line.Split(',');

            if(split.Length % 2 != 0)
            {
                // Errors can happen when creating the file, a stray comma may be at the end or beginning without any content.
                return ErrorCode.INVALID_LENGTH;
            }

            // Line has commas and a valid length. Now they must be parsed into floats.
            float r = 0.0f;
            int index = 0;
            foreach(string s in split)
            {
                w.ReportProgress((index / split.Length) * 100);
                if(!float.TryParse(s, out r))
                {
                    return ErrorCode.INVALID_NUMBER;
                    
                }
                index++;
            }

            // Line has commas, valid length, and parsed into floats correctly. The program may continue.
            return ErrorCode.NONE;
        }



        /// <summary>
        /// ThrowErrorMessage - Switches between the error types to know what message to show the user, and determine if it will stop the program or not.
        /// Currently, no error allows the program to continue in this state.
        /// </summary>
        /// <param name="error">Error Code to determine what error took place.</param>
        /// <returns>Boolean that allows the continuation of the program (Defaults to true)</returns>
        private static bool ThrowErrorMessage(ErrorCode error)
        {
            bool cont = true;

            switch(error)
            {
                case ErrorCode.NO_COMMAS_DETECTED:
                    MessageBox.Show("Comma not detected on line, check your file type. Parsing will not continue.");
                    cont = false;
                    break;
                case ErrorCode.INVALID_LENGTH:
                    MessageBox.Show("Too many or too few numbers were on a single line - The program splits into X/Y coordinates, so each coordinate group is either line by line or an even amount per line. Parsing will not continue.");
                    cont = false;
                    break;
                case ErrorCode.INVALID_NUMBER:
                    MessageBox.Show("A line could not be converted into a number set. Parsing will not continue.");
                    cont = false;
                    break;
                default:
                    break;
            }

            return cont;
        }
    }
}

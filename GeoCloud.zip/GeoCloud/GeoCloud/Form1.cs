﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Web.UI;
using System.Data.OleDb;
using MapWinGIS;

namespace GeoCloud
{
    public partial class Form1 : Form
    {
        string sr, csv;

        public Form1()
        {
            InitializeComponent();
        }

        //When the export button is hit
        private void button1_Click(object sender, EventArgs e)
        {
            string fName = textBox7.Text;
            string shpName = textBox3.Text;

            if (File.Exists(fName))
            {
                DialogResult res = MessageBox.Show("A KML file of the same name has been detected. Would you like to overwrite it?", "Error: File Detected", MessageBoxButtons.YesNo);
                if (res == DialogResult.Yes)
                {
                    File.Delete(fName);
                    //Save over KML
                    string[] str = { "" };
                    str[0] = richTextBox1.Text;
                    File.WriteAllLines(fName, str);
                }
                else
                {
                    return;
                }
            }
            else
            {
                //Export
                string[] str = { "" };
                str[0] = richTextBox1.Text;
                File.WriteAllLines(fName, str);
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        /*
         * If the "Import Excel File" button was clicked
         */
        private void button2_Click(object sender, EventArgs e)
        {
            sr = GetExcelFile();
            csv = textBox2.Text;
            //var gForm = new ExcelFile();
           // gForm.Parse(sr);

        }

        /*
         * If the "Convert to CSV" Button was clicked
         */ 
        private void button3_Click(object sender, EventArgs e)
        {
            MakeCSV(sr, csv, 1);
            CheckTownship(csv);
        }

        #region SHP Loading
        /*
         * Use an OpenFileDialog and get the SHP and other files.
         */
        private string GetSHPFile()
        {
            openFileDialog1.Filter = "Shapefile (*.shp)|*.shp";
            openFileDialog1.Title = "Select a SHP File";
            string fName = "";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    fName = openFileDialog1.InitialDirectory + openFileDialog1.FileName;
                    textBox3.Text = openFileDialog1.InitialDirectory + openFileDialog1.FileName;

                    
                    //Change ListView to Items with the same name
                    listBox1.Items.Clear();

                    
                    string fN2 = openFileDialog1.FileName.Replace(".shp", "");
                    string dir = System.IO.Path.GetDirectoryName(openFileDialog1.FileName);

                    string[] fList = Directory.GetFiles(dir);
                    
                    foreach (string f in fList)
                    {
                        if(f.Contains(fN2))
                        {
                            string file = Path.GetFileName(f);
                            listBox1.Items.Add(file);
                        }
                    }

                    textBox7.Text = openFileDialog1.FileName.Replace(".shp", ".kml");

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: Could not read file from disk. Error: " + ex.Message);
                }
            }

            loadSHP(fName);
            
            return fName;
        }


        private void loadSHP(string path)
        {
            Shapefile map = new Shapefile();
            GeoProjection proj = new GeoProjection();
            
            
            map.Open(path);
   
            Shape s = map.get_Shape(0);
            axMap1.AddLayer(map, true);

            double degX = 0.0, degY = 0.0;
            //TODO: I DID IT! SUCCESSFUL CONVERSION! NOW GET THIS SHIT WORKING IN THE MORNING!!
            //It's not perfect. Play with the numbers and make modifications.
            //Don't worry about it for now.
            double prjX = 0.0, prjY = 0.0;
            axMap1.PixelToProj(s.get_Point(1).x, s.get_Point(1).y, ref prjX, ref prjY);

            double centX = 0.0, centY = 0.0;
            bool set = axMap1.ProjToDegrees(s.get_Point(0).x, s.get_Point(0).y, ref degX, ref degY);
            bool set2 = axMap1.ProjToDegrees(s.Center.x, s.Center.y, ref centX, ref centY);

            
            
            
           
        }
        #endregion

        #region Excel to CSV
        /*
         * Use an OpenFileDialog and get the Excel File
         */ 
        private string GetExcelFile()
        {
            //Set the Filter and Title of the Open File Dialog
            openFileDialog1.Filter = "Microsoft Excel (*.xlsx, *.xls)|*.xlsx;*.xls|All Files (*.*)|*.*";
            openFileDialog1.Title = "Select a Data Table";
            string fName = "";
            //If the User Clicks OK
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                
                try
                {

                    //Assign the opened file to a dataset.
                    //openfileDialog1.OpenFile();

                    //Change the text in the nearby textbox to the Directory
                    textBox1.Text = openFileDialog1.InitialDirectory + openFileDialog1.FileName;
                    fName = openFileDialog1.InitialDirectory  + openFileDialog1.FileName;
                    //Change the text in the textbox below to show the output file if it is converted.
                    if (openFileDialog1.FileName.Contains(".xlsx"))
                        textBox2.Text = openFileDialog1.InitialDirectory + openFileDialog1.FileName.Replace(".xlsx", ".csv");
                    else if (openFileDialog1.FileName.Contains(".xls"))
                        textBox2.Text = openFileDialog1.InitialDirectory + openFileDialog1.FileName.Replace(".xls", ".csv");
                    
                }
                catch (Exception exc)
                {
                    MessageBox.Show("Error: Could not read file from disk. Error: " + exc.Message);

                }
            }

            return fName;
        }


        /*
         * Convert the Excel File to a CSV so it can be joined to a DBF.
         * First run MakeCSV, which checks if files exist or not, then calls Convert().
         */
        private void MakeCSV(string filePath, string outputFile, int worksheetNumber)
        {
            //Check if the Excel file can be found.
            if (!File.Exists(filePath))
            {
                MessageBox.Show("Error A100 - File Not Found");
                return;
            }
            

            //Check if the output file already exists or not.
            //If it does, display the error box and allow overwriting.
            if (File.Exists(outputFile))
            {
                DialogResult dR = MessageBox.Show("File already exists! Overwrite?", "Error B100", MessageBoxButtons.YesNo);
                if (dR == DialogResult.Yes)
                {
                    //Run the Conversion
                    Convert(filePath, outputFile, worksheetNumber);
                    return;
                }
                else if (dR == DialogResult.No)
                {
                    //throw new ArgumentException();
                    return;
                }
            }

            Convert(filePath, outputFile, worksheetNumber);
        }

        /*
         * Make the XLS into a CSV
         */
        private void Convert(string filePath, string outputFile, int worksheetNumber)
        {
            //Connect to the Tables
            var cStr = String.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Extended Properties=\"Excel 8.0;IMEX=1;HDR=NO\"", filePath);
            var con = new OleDbConnection(cStr);

            var dTable = new DataTable();

            try
            {
                //Open a connection and get the Schema
                con.Open();
                var schema = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

                //Check if a worksheet exists. 
                //TODO: Get it to work with any chosen worksheet.
                if (schema.Rows.Count < worksheetNumber)
                    throw new ArgumentException("Error AC100 - The worksheet number provided cannot be found in the spreadsheet.");

                string ws = schema.Rows[worksheetNumber - 1]["table_name"].ToString().Replace("'", "");
                string sql = String.Format("SELECT * FROM [{0}]", ws);
                var adapter = new OleDbDataAdapter(sql, con);

                adapter.Fill(dTable);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception: " + ex);
            }
            finally
            {
                con.Close();
            }

            using (var writer = new StreamWriter(outputFile))
            {
                foreach (DataRow row in dTable.Rows)
                {
                    bool first = true;
                    foreach (DataColumn col in dTable.Columns)
                    {
                        if (!first)
                            writer.Write(",");
                        else
                            first = false;

                        var data = row[col.ColumnName].ToString().Replace("\"", "\"\"");
                        writer.Write(String.Format("\"{0}\"", data));
                    }
                    writer.WriteLine();

                }
            }

            MessageBox.Show("Conversion Successful! The program will now check for township information. You may be asked to import the Township and Section SHP files.", "GeoCSV");

        }
        #endregion

        /*
         * Check the CSV for the corresponding Township Information.
         */
        private void CheckTownship(string csvFile)
        {
            //Run through the CSV and find all matching data

            //If the data is found, search the "Townships" folder in the chosen Preference folder.

            //If any of the files match the Township and Section Name, then proceed.

            //If no match is found, ask the user to import the Township and Section Name
            

            //Use System.IO.File.Copy(@oldPath, @newPath) to copy the info into the folder and name the files for later use.

        }

        private void openSHPToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            GetSHPFile();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        //When the Join CSV and SHP is clicked
        private void button5_Click(object sender, EventArgs e)
        {

        }

        //Generate HTML Button is clicked
        private void button6_Click(object sender, EventArgs e)
        {
            string fName = textBox7.Text;
            string shpName = textBox3.Text;
            ConvertToKML(shpName, fName);
        }

        private string GenerateHTML()
        {
            //First, Generate the Head.
            StringWriter sW = new StringWriter();

            #region MetaData
            sW.WriteLine("{0}", "<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">");
            sW.WriteLine("{0}", "<html>");
            sW.WriteLine("{0}", "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">");
            sW.WriteLine("{0}", "<meta http-equiv=\"Content-Style-Type\" content=\"text/css\">");
            sW.WriteLine("{0}", "<title></title>");
            sW.WriteLine("{0}", "<meta name=\"Generator\" content=\"Cocoa HTML Writer\">");
            sW.WriteLine("{0}", "<meta name=\"CocoaVersion\" content=\"1038.36\">");
            #endregion MetaData

            #region Points
            sW.WriteLine("{0}", "<style type=\"text/css\">");
            sW.WriteLine("{0}", "p.p1 {margin: 0.0px 0.0px 0.0px 0.0px; font: 17.0px Arial}");
            sW.WriteLine("{0}", "p.p2 {margin: 0.0px 0.0px 0.0px 0.0px; text-align: center; font: 13.0px Arial}");
            sW.WriteLine("{0}", "p.p3 {margin: 0.0px 0.0px 0.0px 0.0px; text-align: right; font: 10.0px Arial}");
            sW.WriteLine("{0}", "p.p4 {margin: 0.0px 0.0px 0.0px 0.0px; font: 10.0px Arial}");
            sW.WriteLine("{0}", "p.p5 {margin: 0.0px 0.0px 0.0px 0.0px; font: 15.0px Cambria}");
            sW.WriteLine("{0}", "p.p6 {margin: 0.0px 0.0px 0.0px 0.0px; text-align: center; font: 10.0px Arial}");
            sW.WriteLine("{0}", "table.t1 {background-color: #acdbd0; border-style: solid; border-width: 1.0px 1.0px 1.0px 1.0px; border-color: #ffffff #ffffff #ffffff #ffffff}");
            sW.WriteLine("{0}", "td.td1 {width: 302.0px; border-style: solid; border-width: 1.0px 1.0px 1.0px 1.0px; border-color: #ffffff #ffffff #ffffff #ffffff; padding: 4.0px 4.0px 4.0px 4.0px}");
            sW.WriteLine("{0}", "td.td2 {width: 150.0px; border-style: solid; border-width: 1.0px 1.0px 1.0px 1.0px; border-color: #ffffff #ffffff #ffffff #ffffff; padding: 4.0px 4.0px 4.0px 4.0px}");
            sW.WriteLine("{0}", "td.td3 {width: 142.0px; border-style: solid; border-width: 1.0px 1.0px 1.0px 1.0px; border-color: #ffffff #ffffff #ffffff #ffffff; padding: 4.0px 4.0px 4.0px 4.0px}");
            sW.WriteLine("{0}", "</style>");
            sW.WriteLine("{0}", "</head>");
            #endregion

            #region Body
            sW.WriteLine("{0}", "<body>");
            sW.WriteLine("{0}", "");
            //Depending on how many owners there are, set amount of pages.
            sW.WriteLine("{0}", "");

            //Set Page content depending on amount of pages.

            #endregion


  
            return sW.ToString();

            //Generate the Output File Name:

        }

        private string GetTractTitle()
        {
            //Go through the CSV and find the Title.

            //How to handle if more than one landpiece? We should probably get the index of the shapefile.
            //Then we can loop again.
            return "True";
        }

//Region Start: KML Conversion
        public void ConvertToKML(string SHPName, string KMLName)
        {
            //Open the Shape File
            Shapefile shp = new Shapefile();
            if (!shp.Open(SHPName))
                MessageBox.Show("Failed to open shapefile!");
               
            //Open the KML File;
            StringWriter KML;
            KML = OpenKMLFile(KMLName);

            //Loop through the shape file, shape by shape.
            int shpIndex, convertedshpCount;
            convertedshpCount = 0;

            //Loop through all the shapes in the SHP
            for (shpIndex = 0; shpIndex < shp.NumShapes; shpIndex++)
            {
                //Process Each Shape Depending on ShapeType
                switch (shp.get_Shape(shpIndex).ShapeType)
                {
                    case ShpfileType.SHP_POLYGON:
                        AddPolygonKML(shp.get_Shape(shpIndex), KML, shpIndex.ToString());
                        convertedshpCount++;
                        break;
                    default:
                        MessageBox.Show("Shape #" + shpIndex + " of type " + shp.get_Shape(shpIndex).ShapeType + " is not supported yet.");
                        break;
                }

            }

            richTextBox1.Text = KML.ToString();
            richTextBox1.Text += "Hmmm";

            //Next we need to get the Township by going through the Townships Folder.
            //Then get the sections. They should have been imported already.
            //Repeat above code.

            //Now change the textbox Text.



            CloseKMLFile(KML);
        }

     
        public StringWriter OpenKMLFile(string KML)
        {
            //Prevent appending from multiple runs
            //Delete the existing file, if any
            //If File.Exists, Delete
         
            //Create a new text file to write the KML to
            StringWriter oW = new StringWriter();

            //Create the XML Header
            oW.WriteLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            oW.WriteLine("<kml xmlns=\"http://earth.google.com/kml/2.2\">");
            oW.WriteLine("<Folder>"); //Don't forget to close out.
            oW.WriteLine("<name>Land Info (Temporary)</name>");
            oW.WriteLine("<open>1</open>");

            richTextBox1.Text = oW.ToString();
            return oW;

        }

        /*
         * Close out the StreamWriter, free up resources.
         */ 
        public void CloseKMLFile(StringWriter oW)
        {
            oW.WriteLine("</Folder>");
            oW.WriteLine("</kml>");

            richTextBox1.Text = oW.ToString();
            oW.Close();

        }

        public void AddPolygonKML(Shape shp, StringWriter oW, string ShapeID)
        {
            //Key Parameters for defining the KML Polygon points:
            double latdeg, longdeg, height;

            //Going to need to generate the Land Tract Number along with the styles first.
            oW.WriteLine("<Document>");
            oW.WriteLine("  <name>Tr-" + GetTractTitle() + "</name>");

            //TODO: Allow Style Changes
            #region Styles
            oW.WriteLine("  <Style id=\"area1\">");
            oW.WriteLine("      <IconStyle><Icon></Icon></IconStyle>");
            oW.WriteLine("      <LabelStyle><scale>0.6</scale></LabelStyle>");
            oW.WriteLine("      <BalloonStyle><text>$[description]</text></BalloonStyle>");
            oW.WriteLine("      <LineStyle><color>ff00ffff</color><width>3</width></LineStyle>");
            oW.WriteLine("      <PolyStyle><color>bf000000</color><fill>0</fill></PolyStyle>");
            oW.WriteLine("  </Style>");

            oW.WriteLine("  <Style id=\"area11\">");
            oW.WriteLine("      <IconStyle><Icon></Icon></IconStyle>");
            oW.WriteLine("      <LabelStyle><scale>0.6</scale></LabelStyle>");
            oW.WriteLine("      <BalloonStyle><text>$[description]</text></BalloonStyle>");
            oW.WriteLine("      <LineStyle><color>ff00ffff</color><width>3</width></LineStyle>");
            oW.WriteLine("      <PolyStyle><color>bf000000</color><fill>0</fill></PolyStyle>");
            oW.WriteLine("  </Style>");

            oW.WriteLine("  <StyleMap id=\"area10\">");
            oW.WriteLine("      <Pair><key>normal</key><styleUrl>#area1</styleUrl></Pair>");
            oW.WriteLine("      <Pair><key>highlight</key><styleUrl>#area11</styleUrl></Pair>");
            oW.WriteLine("  </StyleMap>");
            #endregion


            oW.WriteLine("  <Placemark>");
            oW.WriteLine("      <name>" + GetTractTitle() + "</name>"); 
                //To get the Name, Search every line on the CSV. If the titles are similar or have been used before, do not use again.
            //oW.WriteLine("      <description>" + GenerateHTML().ToString() + "</description>");
            oW.WriteLine("      <styleUrl>#area10</styleUrl>");
            oW.WriteLine("      <MultiGeometry>");
            oW.WriteLine("          <Polygon>");
            oW.WriteLine("              <outerBoundaryIs>");
            oW.WriteLine("                  <LinearRing>");
            oW.WriteLine("                      <coordinates>");
                oW.Write("                          ");

            //Loop through all the points and extract them
            int pointIndex;
            for (pointIndex = 0; pointIndex < shp.numPoints; pointIndex++)
            {
                double prjX = 0.0, prjY = 0.0;
                axMap1.PixelToProj(shp.get_Point(pointIndex).x, shp.get_Point(pointIndex).y, ref prjX, ref prjY);

                double degX = 0.0, degY = 0.0;
                bool set = axMap1.ProjToDegrees(shp.get_Point(pointIndex).x, shp.get_Point(pointIndex).y, ref degX, ref degY);

                longdeg = degX - .0002;
                latdeg = degY + .0002;
                height = shp.get_Point(pointIndex).Z;

                //Create KML Coordinates as <lon, lat, height> {space}
                oW.Write(longdeg + ",");
                oW.Write(latdeg + ",");
                oW.Write(height + " ");
                oW.WriteLine();

            }

            //Close them
            oW.WriteLine("                      </coordinates>");
            oW.WriteLine("                  </LinearRing>");
            oW.WriteLine("              </outerBoundaryIs>");
            oW.WriteLine("          </Polygon>");
            oW.WriteLine("      </MultiGeometry>");
            oW.WriteLine("  </Placemark>");
            oW.WriteLine("</Document>");

            richTextBox1.Text += oW.ToString();
            
        }



        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
        
    }
}

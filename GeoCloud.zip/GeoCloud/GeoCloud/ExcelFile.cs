﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace GeoCloud
{
    public partial class ExcelFile : Form
    {
        public ExcelFile()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }


        /// <summary>
        /// This allows the program to Parse Excel Data to view in ExcelFile.cs
        /// </summary>
        /// <param name="fileName">Gets a File that was opened</param>
        /// <returns>Returns a DataSet</returns>
        public DataSet Parse(string fileName)
        {
            string connStr = string.Format("provider=Microsoft.Jet.OLEDB.4.0; data source={0};Extended Properties=Excel 8.0;", fileName);

            DataSet data = new DataSet();

            OleDbDataAdapter adapter = new OleDbDataAdapter("SELECT * FROM [" + fileName.Substring(fileName.LastIndexOf(@"\") + 1, fileName.Length - 1)  + "]", connStr);
            DataSet ds = new DataSet();

            adapter.Fill(ds, "Table");
            DataTable d = ds.Tables["Table"];

            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = data;
            dataGridView1.DataMember = "TableName";

            return data;

        }


        /// <summary>
        /// Returns the Excel Sheet Names to place in the DataSet
        /// </summary>
        /// <param name="connStr"></param>
        /// <returns></returns>
        static string[] GetExcelSheetNames(string connStr)
        {
            //Set up our table and connections
            OleDbConnection con = null;
            DataTable table = null;

            con = new OleDbConnection(connStr);
            con.Open();
            table = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

            if (table == null)
            {
                return null;
            }

            //Get the number of rows in the sheet.
            String[] exSheets = new String[table.Rows.Count];

            int k = 0;

            foreach (DataRow row in table.Rows)
            {
                exSheets[k] = row["TABLE_NAME"].ToString();
                k++;
            }

            return exSheets;
        }


       
        
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Threading;
using System.Threading.Tasks;

namespace GeoCloud
{

    /// <summary>
    /// The GeometryType enumeration defines geometry types that
    /// can be used when creating WPF shapes. Choosing a stream
    /// geometry type can improve rendering performance.
    /// </summary>
    public enum GeometryType
    {
        /// <summary>
        /// Use path geometry containing path figures.
        /// </summary>
        UsePathGeometry,

        /// <summary>
        /// Use StreamGeometry with StreamGeometryContext class
        /// to specify drawing instructions.
        /// </summary>
        UseStreamGeometry,

        /// <summary>
        /// Same as UseStreamGeometry except that the figures
        /// will be unstroked for greater performance (borders
        /// won't be displayed for the shapes).
        /// </summary>
        UseStreamGeometryNotStroked
    }

    public class ShapeDisplay
    {
        //Delegates - Defines the prototype for a method that reads a block of
        //shapefile records and creates and dispalys shapes. Executed by the dispatcher
        public delegate void ReadNextPrototype(ShapeFileReadInfo info);
        public delegate void DisplayNextPrototype(ShapeFileReadInfo info);

        //Constants
        private const int readShapeBlockingFactor = 50;
        private const int displayShapesBlockingFactor = 10;
        private const string baseLonLatText = "Lon/Lat: ";

        #region Private Fields
        //UI COMPONENTS
        //Window Owner
        //Canvas canvas
        private Dispatcher dispatcher;
        //Progress Window
        
        //READING SHPs
        private bool isReadingSHP;
        private bool cancelReadSHP;
        private int shapeCount;

        //CREATING SHAPES
        //Shape List
        private GeometryType geoType = GeometryType.UseStreamGeometryNotStroked;

        //Transformation from lon/lat to canvas coordinates
        //TransformGroup shapeTransform;
        //TransformGroup viewTransform = new TransformGroup();
        //ScaleTransform zoom = new ScaleTransform();
        //TranslateTransform panTransform = new TranslateTransform();

        //COLORING SHAPES
        private Brush[] shapeBrushes;
        private Random rand = new Random(379013);
        private Brush stroke = new SolidBrush(Color.FromArgb(150,150,150,150));
        
        //PANNING OPS
        private bool isPanningEnabled = true;
        System.Windows.Point prevMouseLocation;
        bool isMouseDrag;
        private double panTolerance = 1;
        
        //DISPLAYING LAT/LON COORDINATES ON CANVAS
        bool isDisplayLonLatEnabled = true;
        System.Windows.Forms.Label lonlatLabel = new System.Windows.Forms.Label();
        #endregion

        #region Constructor

        public ShapeDisplay()
        {
            
        }

        #endregion

        #region Properties

        public bool IsReadingShapeFile
        {
            get { return this.IsReadingShapeFile; }
        }

        public bool CanZoom
        {
            get { return true; }
        }

        //Needed:
        //IsPanningEnabled
        //IsDisplayLonLatEnabled

        public GeometryType GeometryType
        {
            get { return this.geoType; }
            set { this.geoType = value; }
        }


        #endregion



    }
}

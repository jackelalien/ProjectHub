﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeoCloud
{
    class KMLGeneration
    {
    }

    public class Placemark
    {
        char[] delimiter = { ',' };
        #region Constructors
        public Placemark(string raw)
        {
            string[] tokens = raw.Split(delimiter);
            string CLECO_ID = tokens[0];
            string ParishCounty = "";
        }

        public Placemark()
        {
        }
        #endregion
    }
}
